# Florida Man Plumbing (GitHub Pages)

## Deploy
1. Create a new GitHub repo
2. Upload everything in this folder to the repo root
3. Go to **Settings → Pages**
   - Source: Deploy from a branch
   - Branch: `main` / root
4. Your site will be live at your GitHub Pages URL.

## Update phone number
Search for `+1 (941) 468-6310` and `19414686310` across files.
